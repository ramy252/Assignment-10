import jwt from "jsonwebtoken";
import {
  ACCESS_TOKEN_USER_SECRET,
  ACCESS_TOKEN_USER_EXPIRES_IN,
  REFRESH_TOKEN_USER_SECRET,
  REFRESH_TOKEN_ADMIN_SECRET,
  ACCESS_TOKEN_ADMIN_SECRET,
  REFRESH_TOKEN_USER_EXPIRES_IN,
  ACCESS_TOKEN_ADMIN_EXPIRES_IN,
  REFRESH_TOKEN_ADMIN_EXPIRES_IN,
} from "../../config/process.js";
import { RoleEnum, SignatureEnum } from "../enum/user.enum.js";
// export const generateToken = ({ payload, secretKey, option }) => {
//   return jwt.sign(payload, secretKey, option);
// };
// export const verifyToken = ({ token, secretKey }) => {
    
//   return jwt.verify(token, secretKey);
// };

// export const getSignature = ({ signatureLeve = null }) => {
//   let signature = { accessSignature: undefined, refreshSignature: undefined };
//   switch (signatureLeve) {
//     case SignatureEnum.ADMIN:
//       signature.accessSignature = ACCESS_TOKEN_ADMIN_SECRET;
//       signature.refreshSignature = REFRESH_TOKEN_ADMIN_SECRET;
//       console.log("admin");
//       break;
//     case SignatureEnum.USER:
//       signature.accessSignature = ACCESS_TOKEN_USER_SECRET;
//       signature.refreshSignature = REFRESH_TOKEN_USER_SECRET;
//       console.log("user");
//       break;
//     default:
//       signature.accessSignature = ACCESS_TOKEN_USER_SECRET;
//       signature.refreshSignature = REFRESH_TOKEN_USER_SECRET;
      
//       break;
//   }
//   return signature;
// };

// export const getNewLogicCredentials = async (user) => {
//   const signature = getSignature({
//     signatureLeve: user.role != RoleEnum.ADMIN ? SignatureEnum.USER : SignatureEnum.ADMIN,
//   });

//   let accessToken = generateToken({
//     payload: { id: user._id },
//     secretKey: signature.accessSignature,
//     option: {
//       subject: "user_id",
//       issuer: "auth-service",
//       audience: "sarahah_app",
//       expiresIn:
//         user.role === RoleEnum.ADMIN
//           ? Number(ACCESS_TOKEN_ADMIN_EXPIRES_IN)
//           : Number(ACCESS_TOKEN_USER_EXPIRES_IN),
//     },
//   });
//   let refreshToken = generateToken({
//     payload: { id: user._id },
//     secretKey: signature.refreshSignature,
//     option: {
//       subject: "user_id",
//       issuer: "auth-service",
//       audience: "sarahah_app",
//       expiresIn:
//         user.role === RoleEnum.ADMIN
//           ? Number(REFRESH_TOKEN_ADMIN_EXPIRES_IN)
//           : Number(REFRESH_TOKEN_USER_EXPIRES_IN),
//     },
//   });
// console.log("User Role:", user.role);
// console.log("RoleEnum.ADMIN:", RoleEnum.ADMIN);
// console.log("Signature:", signature);
//   return {
//     accessToken,
//     refreshToken,
//   };
// };

export const generateToken = ({ payload, secretKey, option }) => {
  return jwt.sign(payload, secretKey, option);
};
export const verifyToken = ({ token, secretKey }) => {
  
  return jwt.verify(token, secretKey);
};

export const getSignature = ({ signatureLeve = null }) => {
  let signature = { accessSignature: undefined, refreshSignature: undefined };
  switch (signatureLeve) {
    case SignatureEnum.ADMIN:
      signature.accessSignature = ACCESS_TOKEN_ADMIN_SECRET;
      signature.refreshSignature = REFRESH_TOKEN_ADMIN_SECRET;
      signature.expiresIn = ACCESS_TOKEN_ADMIN_EXPIRES_IN;
      console.log("admin");
      break;
    case SignatureEnum.USER:
      signature.accessSignature = ACCESS_TOKEN_USER_SECRET;
      signature.refreshSignature = REFRESH_TOKEN_USER_SECRET;
      signature.expiresIn = ACCESS_TOKEN_USER_EXPIRES_IN;
      console.log("user");
      break;
    default:
      signature.accessSignature = ACCESS_TOKEN_USER_SECRET;
      signature.refreshSignature = REFRESH_TOKEN_USER_SECRET;
      
      break;
  }
  return signature;
};

export const getNewLogicCredentials = async (user) => {
  const signature = getSignature({
    signatureLeve: user.role != RoleEnum.ADMIN ? SignatureEnum.USER : SignatureEnum.ADMIN,
  });

  let accessToken = generateToken({
    payload: { id: user._id },
    secretKey: signature.accessSignature,
    option: {
      subject: "user_id",
      issuer: "auth-service",
      audience: "sarahah_app",
      expiresIn: signature.expiresIn,
    },
  });
  let refreshToken = generateToken({
    payload: { id: user._id },
    secretKey: signature.refreshSignature,
    option: {
      subject: "user_id",
      issuer: "auth-service",
      audience: "sarahah_app",
      expiresIn: signature.expiresIn,
    },
  });
console.log("User Role:", user.role);
console.log("RoleEnum.ADMIN:", RoleEnum.ADMIN);
console.log("Signature:", signature);
  return {
    accessToken,
    refreshToken,
  };
};
